<?php 
include('../../../../wp-config.php');
global $wpdb;
global $table_prefix;
        $data = array(
            'name'     => $_POST['username'],
            'email'    => $_POST['useremail'],
            'cabs'     => $_POST['cab'],
            'datetime' => date('Y-m-d H:i:s', strtotime(str_replace('-', '/', $_POST['datetime']))),
            'message'  => $_POST['message']
        );
        $table = $table_prefix.'cab'; // Use 'prefix' instead of 'table_prefix'
        echo $table;
        
        $sql = $wpdb->insert($table, $data);

        if ($sql == true) {
            echo "<script>alert('Data saved');</script>";
        } else {
            echo "<script>alert('Failed');</script>";
        }

        $to_email = $_POST['useremail'];
        $subject = "Simple Email Testing via PHP";
        $body = "Hello,nn It is a testing email sent by PHP Script";
        $body1 = "Hello,nn It is a testing email sent by PHP Script for admin";
        $headers = "From: nriya5892@gmail.com";
       
        if (mail($to_email, $subject, $body, $headers)) {
          echo "Email successfully sent to $to_email...";
        } else {
          echo "Email sending failed...";
        }

        $admin = get_option( 'admin_email' );
        $headers = "From: nriya5892@gmail.com";
        mail($admin, $subject, $body1, $headers);
    
?>
