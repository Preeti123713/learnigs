$(document).ready(function(){
  var ajax_url= jQuery('#path').val();
  var id =$('#id').val();
  $.ajax({
    type: "GET",
    url: ajax_url,
  data:{id:id},
    // dataType: "html",
    success: function (data) {
      alert(data);
      //     $('#msg').html(data);
      //    $('#table-container').load('fetch-data.php');
    },
  });
});
