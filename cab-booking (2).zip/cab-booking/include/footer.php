<?php  wp_enqueue_script( 'insertajax', plugin_dir_url(__FILE__).'js/insertajax.js',NULL,NULL, true ); ?>
<?php  wp_enqueue_script( 'updateajax', plugin_dir_url(__FILE__).'js/updateajax.js',NULL,NULL, true ); ?>
<script>
        $('#input').datetimepicker({
            uiLibrary: 'bootstrap4',
            modal: true,
            footer: true
        });
</script>
<script>
        $('#input').datetimepicker({
            uiLibrary: 'bootstrap4',
            modal: true,
            footer: true
        });
    </script>
  </body>
</html>