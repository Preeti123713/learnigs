<?php
include( '../../../../wp-config.php' );
global $wpdb;
global $table_prefix;
var_dump($_POST['id']);
$id = $_POST['id'];
$name = $_POST[ 'username' ];
$email = $_POST[ 'useremail' ];
$cab = $_POST[ 'cab' ];
$datetime = date( 'Y-m-d H:i:s', strtotime( str_replace( '-', '/', $_POST[ 'datetime' ] ) ) );
$message = $_POST[ 'message' ];
  $sql = "UPDATE  wp_cab SET name='$name',email='$email',cab`='$cab',datetime='$datetime' WHERE id='$id'"; 

 $query= $wpdb->query($sql);
if ( $query == true ){
    echo "Data updated";
}else{ 

    echo "Error:" . $sql . "<br>" . esc_sql( $wpdb->last_error );

}

?>

