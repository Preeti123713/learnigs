<?php
global $wpdb;
global $table_prefix;
$id = $_GET['id'];

$table = $table_prefix.'cab';
 $sql=    "DELETE FROM wp_cab WHERE id='".$id."'";
 $query= $wpdb->query($sql);
 if ( $query == true ) {
    echo "<script>alert('Data Deleted' );</script>";
} else {
    echo "<script>alert('Data is not Deleted. Error: " . esc_sql( $wpdb->last_error ) . "');</script>";
}
?>
