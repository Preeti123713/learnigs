<?php 
include('../../../../wp-config.php');
global $wpdb;
global $table_prefix;
    // if (isset($_POST['submit'])) {
        $data = array(
            'name'     => $_POST['username'],
            'email'    => $_POST['useremail'],
            'cabs'     => $_POST['cab'],
            'datetime' => date('Y-m-d H:i:s', strtotime(str_replace('-', '/', $_POST['datetime']))),
            'message'  => $_POST['message']
        );
        $table = $table_prefix.'cab'; // Use 'prefix' instead of 'table_prefix'
        echo $table;
        
        $sql = $wpdb->insert($table, $data);

        if ($sql == true) {
            echo "<script>alert('Data saved');</script>";
        } else {
            echo "<script>alert('Failed');</script>";
        }
    // }
?>
